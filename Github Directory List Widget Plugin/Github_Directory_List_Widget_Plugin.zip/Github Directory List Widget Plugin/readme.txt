=== Github File List Widget Plugin ===
Plugin Name: Github File List Widget Plugin
Plugin URI: 
Author: Kerem Bilgehan Gül
Author URI: http://wwphp.com
Contributors: wwphp
Tags: github, repo, file, list, plugin
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tested up to: 5.4
Stable tag: 2.0.1
Requires PHP: 5.2

Show your list github files on your web site.

== Description ==

Show your list files on your github repos with Github File List Widget Plugin

This plugin uses the following resources for data : 
-This plugin used Github API on www.github.com

== Installation ==

1.Upload the Github File List Widget Plugin zip file to your blog, activate it, and then enter your Youtube API key.

== Screenshots ==

1. Github File List Widget Plugin Backend
2. Github File List Widget Plugin Frontend

== Changelog ==

= 1.0 =
* First stable release Github File List Widget Plugin.
